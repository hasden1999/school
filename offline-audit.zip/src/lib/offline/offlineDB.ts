/**
 * Native IndexedDB Service for School SaaS Offline-First Operation
 * Supports local data caching, offline drafting, and outbox sync queue.
 */

const DB_NAME = "NukhbaSchoolOfflineDB";
const DB_VERSION = 2;

export interface SyncQueueItem {
  id: string;
  type: "ATTENDANCE" | "GRADE" | "PAYMENT" | "STUDENT_CREATE";
  payload: any;
  timestamp: string;
  status: "PENDING" | "SYNCING" | "FAILED";
  retryCount: number;
}

export interface CachedSchoolBundle {
  tenantId: string;
  schoolName: string;
  schoolType: string;
  currency: string;
  classRooms: any[];
  sections: any[];
  subjects: any[];
  students: any[];
  teachers: any[];
  lastCachedAt: string;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !window.indexedDB) {
      reject(new Error("IndexedDB is not available in this environment"));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: any) => {
      const db: IDBDatabase = event.target.result;

      // 1. Cached School Master Data
      if (!db.objectStoreNames.contains("cachedSchool")) {
        db.createObjectStore("cachedSchool", { keyPath: "tenantId" });
      }

      // 2. Outbox Sync Queue for offline mutations
      if (!db.objectStoreNames.contains("syncQueue")) {
        const queueStore = db.createObjectStore("syncQueue", { keyPath: "id" });
        queueStore.createIndex("status", "status", { unique: false });
        queueStore.createIndex("timestamp", "timestamp", { unique: false });
      }

      // 3. Local Attendance Drafts
      if (!db.objectStoreNames.contains("attendanceLocal")) {
        db.createObjectStore("attendanceLocal", { keyPath: "localKey" });
      }

      // 4. Local Grades Drafts
      if (!db.objectStoreNames.contains("gradesLocal")) {
        db.createObjectStore("gradesLocal", { keyPath: "localKey" });
      }

      // 5. Local Payment Receipts
      if (!db.objectStoreNames.contains("paymentsLocal")) {
        db.createObjectStore("paymentsLocal", { keyPath: "id" });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// -------------------------------------------------------------
// CACHED SCHOOL DATA
// -------------------------------------------------------------

export async function saveSchoolCache(bundle: CachedSchoolBundle): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("cachedSchool", "readwrite");
    const store = tx.objectStore("cachedSchool");
    const req = store.put(bundle);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getSchoolCache(tenantId?: string): Promise<CachedSchoolBundle | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("cachedSchool", "readonly");
      const store = tx.objectStore("cachedSchool");

      if (tenantId) {
        const req = store.get(tenantId);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
      } else {
        const req = store.getAll();
        req.onsuccess = () => {
          const results = req.result;
          resolve(results && results.length > 0 ? results[0] : null);
        };
        req.onerror = () => reject(req.error);
      }
    });
  } catch {
    return null;
  }
}

// -------------------------------------------------------------
// OUTBOX SYNC QUEUE
// -------------------------------------------------------------

export async function enqueueSync(
  type: SyncQueueItem["type"],
  payload: any
): Promise<SyncQueueItem> {
  const item: SyncQueueItem = {
    id: `sync_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    type,
    payload,
    timestamp: new Date().toISOString(),
    status: "PENDING",
    retryCount: 0,
  };

  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("syncQueue", "readwrite");
    const store = tx.objectStore("syncQueue");
    const req = store.put(item);
    req.onsuccess = () => resolve(item);
    req.onerror = () => reject(req.error);
  });
}

export async function getPendingSyncItems(): Promise<SyncQueueItem[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("syncQueue", "readonly");
      const store = tx.objectStore("syncQueue");
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function removeSyncItem(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("syncQueue", "readwrite");
    const store = tx.objectStore("syncQueue");
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function clearSyncedItems(): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("syncQueue", "readwrite");
    const store = tx.objectStore("syncQueue");
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// -------------------------------------------------------------
// LOCAL DRAFTS (ATTENDANCE / GRADES / PAYMENTS)
// -------------------------------------------------------------

export async function saveLocalAttendance(
  classRoomId: string,
  sectionId: string,
  dateStr: string,
  records: any[]
): Promise<void> {
  const localKey = `${classRoomId}_${sectionId}_${dateStr}`;
  const data = {
    localKey,
    classRoomId,
    sectionId,
    dateStr,
    records,
    savedAt: new Date().toISOString(),
  };

  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction("attendanceLocal", "readwrite");
    const store = tx.objectStore("attendanceLocal");
    const req = store.put(data);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });

  // Enqueue for cloud sync
  await enqueueSync("ATTENDANCE", {
    classRoomId,
    sectionId,
    dateStr,
    records,
  });
}

export async function saveLocalGrade(
  classRoomId: string,
  subjectId: string,
  phase: string,
  items: any[]
): Promise<void> {
  const localKey = `${classRoomId}_${subjectId}_${phase}`;
  const data = {
    localKey,
    classRoomId,
    subjectId,
    phase,
    items,
    savedAt: new Date().toISOString(),
  };

  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction("gradesLocal", "readwrite");
    const store = tx.objectStore("gradesLocal");
    const req = store.put(data);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });

  // Enqueue for cloud sync
  await enqueueSync("GRADE", {
    classRoomId,
    subjectId,
    phase,
    items,
  });
}

export async function saveLocalPayment(receiptData: any): Promise<void> {
  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction("paymentsLocal", "readwrite");
    const store = tx.objectStore("paymentsLocal");
    const req = store.put(receiptData);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });

  // Enqueue for cloud sync
  await enqueueSync("PAYMENT", receiptData);
}
