"use client";

import React, { useState } from "react";
import { useOfflineSync } from "@/hooks/useOfflineSync";
import {
  fetchSchoolOfflineBundleAction,
  syncOfflineBatchAction,
} from "@/app/actions/syncActions";
import { executeTwoWayCloudSyncAction } from "@/app/actions/cloudSyncBridgeActions";
import {
  Wifi,
  WifiOff,
  RefreshCw,
  DownloadCloud,
  CheckCircle2,
  AlertCircle,
  Database,
  Layers,
  X,
  Sparkles,
  ArrowUpRight,
  CloudLightning,
} from "lucide-react";

export const OfflineStatusBar: React.FC = () => {
  const {
    isOnline,
    pendingCount,
    pendingItems,
    isSyncing,
    isCaching,
    cachedSchool,
    lastSyncMessage,
    triggerSync,
    cacheSchoolData,
  } = useOfflineSync();

  const [isOpen, setIsOpen] = useState(false);
  const [isCloudSyncing, setIsCloudSyncing] = useState(false);
  const [cloudSyncFeedback, setCloudSyncFeedback] = useState<string | null>(null);

  const handleCloudBridgeSync = async () => {
    setIsCloudSyncing(true);
    setCloudSyncFeedback(null);
    try {
      const res = await executeTwoWayCloudSyncAction();
      if (res.success && res.stats) {
        setCloudSyncFeedback(res.stats.message);
      } else {
        setCloudSyncFeedback(res.error || "تعذرت المزامنة السحابية.");
      }
    } catch (e: any) {
      setCloudSyncFeedback("خطأ في الاتصال: " + e.message);
    } finally {
      setIsCloudSyncing(false);
    }
  };

  return (
    <>
      {/* Header Inline Badge & Trigger */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm border ${
            !isOnline
              ? "bg-amber-500 text-slate-950 border-amber-400 animate-pulse"
              : pendingCount > 0
              ? "bg-amber-50 text-amber-900 border-amber-300"
              : "bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100"
          }`}
          title="حالة الاتصال والمزامنة الأوفلاين"
        >
          {!isOnline ? (
            <>
              <WifiOff className="w-3.5 h-3.5 text-slate-950 shrink-0" />
              <span>أوفلاين (بدون إنترنت)</span>
              {pendingCount > 0 && (
                <span className="bg-slate-950 text-amber-300 text-[10px] px-1.5 py-0.2 rounded-full font-black">
                  {pendingCount}
                </span>
              )}
            </>
          ) : (
            <>
              <Wifi className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="hidden sm:inline">متصل</span>
              {pendingCount > 0 ? (
                <span className="bg-amber-500 text-slate-950 text-[10px] px-1.5 py-0.2 rounded-full font-black animate-pulse">
                  {pendingCount} معلقة
                </span>
              ) : (
                <span className="text-[10px] text-emerald-600 font-bold hidden md:inline">
                  متزامن
                </span>
              )}
            </>
          )}
        </button>
      </div>

      {/* Offline Status & Sync Drawer Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden font-cairo animate-scaleUp">
            {/* Header */}
            <div className="p-5 bg-gradient-to-l from-slate-900 via-slate-800 to-emerald-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center border shadow-inner ${
                    !isOnline
                      ? "bg-amber-500/20 text-amber-400 border-amber-500/30"
                      : "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                  }`}
                >
                  {!isOnline ? <WifiOff className="w-5 h-5" /> : <Wifi className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <span>مركز المزامنة والعمل بدون إنترنت</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        !isOnline
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                          : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      }`}
                    >
                      {!isOnline ? "وضع الأوفلاين نشط" : "متصل بالإنترنت"}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    النظام يعمل محلياً بكامل طاقته في حال انقطاع الشبكة مع مزامنة تلقائية.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 text-xs text-slate-700">
              {/* Feedback Alert */}
              {lastSyncMessage && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{lastSyncMessage}</span>
                </div>
              )}

              {/* Status Summary Card */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-[11px] text-slate-400 font-bold block">
                    العمليات المعلقة للمزامنة
                  </span>
                  <span className="text-xl font-black text-slate-900">
                    {pendingCount} عملية
                  </span>
                  <span className="text-[10px] text-slate-500 block">
                    {pendingCount > 0
                      ? "بانتظار الإرسال للسيرفر السحابي"
                      : "كافة البيانات متزامنة محلياً وسحابياً"}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-[11px] text-slate-400 font-bold block">
                    بيانات المدرسة المحفوظة محلياً
                  </span>
                  <span className="text-xl font-black text-emerald-800">
                    {cachedSchool ? `${cachedSchool.students?.length || 0} طالب` : "غير مخزنة"}
                  </span>
                  <span className="text-[10px] text-slate-500 block truncate">
                    {cachedSchool?.lastCachedAt
                      ? `آخر تحديث: ${new Date(cachedSchool.lastCachedAt).toLocaleTimeString("ar-IQ")}`
                      : "اضغط لتنزيل نسخة المدرسة"}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5">
                {cloudSyncFeedback && (
                  <div className="p-3 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-950 font-bold flex items-center gap-2">
                    <CloudLightning className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>{cloudSyncFeedback}</span>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleCloudBridgeSync}
                  disabled={isCloudSyncing || !isOnline}
                  className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-600 hover:from-indigo-500 hover:to-blue-500 disabled:opacity-50 text-white font-black transition-all shadow-md flex items-center justify-center gap-2"
                >
                  {isCloudSyncing ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CloudLightning className="w-4 h-4 text-amber-300" />
                  )}
                  <span>مزامنة السيرفر السحابي ثنائياً الآن (Two-Way Cloud Sync) ☁️</span>
                </button>

                <button
                  type="button"
                  onClick={triggerSync}
                  disabled={isSyncing || !isOnline || pendingCount === 0}
                  className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black transition-all shadow-md flex items-center justify-center gap-2"
                >
                  {isSyncing ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <RefreshCw className="w-4 h-4" />
                  )}
                  <span>مزامنة العمليات المعلقة الآن ({pendingCount})</span>
                </button>

                <button
                  type="button"
                  onClick={cacheSchoolData}
                  disabled={isCaching || !isOnline}
                  className="w-full py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-black transition-all shadow-md flex items-center justify-center gap-2 border border-slate-700"
                >
                  {isCaching ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <DownloadCloud className="w-4 h-4 text-emerald-400" />
                  )}
                  <span>تحديث وحفظ نسخة المدرسة للعمل أوفلاين (Cache Data) 💾</span>
                </button>
              </div>

              {/* Pending Operations List preview if any */}
              {pendingItems.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <span className="font-black text-slate-800 block text-[11px]">
                    قائمة العمليات المسجلة أوفلاين بانتظار المزامنة:
                  </span>
                  <div className="max-h-36 overflow-y-auto space-y-1.5 scrollbar-thin">
                    {pendingItems.map((item) => (
                      <div
                        key={item.id}
                        className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-[11px]"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">
                            {item.type === "ATTENDANCE"
                              ? "📋 تسجيل حضور وغياب"
                              : item.type === "GRADE"
                              ? "🏆 رصد درجات مرحلية"
                              : item.type === "PAYMENT"
                              ? "💳 سند قبض مالي"
                              : "👤 إضافة طالب"}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {new Date(item.timestamp).toLocaleTimeString("ar-IQ")}
                          </span>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 font-bold">
                          معلق
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-medium">
              <span>💡 المزامنة تعمل آلياً في الخلفية فور التقاط الإنترنت.</span>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="font-bold text-slate-700 hover:text-slate-900"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
